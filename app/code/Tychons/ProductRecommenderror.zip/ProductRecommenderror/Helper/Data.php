<?php
namespace Tychons\ProductRecommend\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    const XML_PATH_ENABLED = 'product_recommend/general/enabled';
    const XML_PATH_PRODUCTS_COUNT = 'product_recommend/general/products_count';
    const XML_PATH_SECTION_TITLE = 'product_recommend/general/section_title';
    const XML_PATH_SECTION_DESCRIPTION = 'product_recommend/general/section_description';

    public function isEnabled($storeId = null)
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    public function getProductsCount($storeId = null)
    {
        $count = (int) $this->scopeConfig->getValue(
            self::XML_PATH_PRODUCTS_COUNT,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
        
        // Default to 4 if not set, max 5
        return max(1, min(5, $count ?: 4));
    }

    public function getSectionTitle($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SECTION_TITLE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        ) ?: 'Recommended for You';
    }

    public function getSectionDescription($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SECTION_DESCRIPTION,
            ScopeInterface::SCOPE_STORE,
            $storeId
        ) ?: 'Products you might be interested in based on your browsing history';
    }
}