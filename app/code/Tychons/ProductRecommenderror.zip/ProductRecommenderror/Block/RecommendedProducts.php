<?php
namespace Tychons\ProductRecommend\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Tychons\ProductRecommend\Model\RecommendationEngine;
use Tychons\ProductRecommend\Helper\Data;
use Magento\Catalog\Helper\Image;
use Magento\Framework\Pricing\Helper\Data as PriceHelper;
use Magento\Catalog\Helper\Output;

class RecommendedProducts extends Template
{
    protected $recommendationEngine;
    protected $helper;
    protected $imageHelper;
    protected $priceHelper;
    protected $outputHelper;

    public function __construct(
        Context $context,
        RecommendationEngine $recommendationEngine,
        Data $helper,
        Image $imageHelper,
        PriceHelper $priceHelper,
        Output $outputHelper,
        array $data = []
    ) {
        $this->recommendationEngine = $recommendationEngine;
        $this->helper = $helper;
        $this->imageHelper = $imageHelper;
        $this->priceHelper = $priceHelper;
        $this->outputHelper = $outputHelper;
        parent::__construct($context, $data);
    }

    public function isEnabled()
    {
        return $this->helper->isEnabled();
    }

    public function getSectionTitle()
    {
        return $this->helper->getSectionTitle();
    }

    public function getSectionDescription()
    {
        return $this->helper->getSectionDescription();
    }

    public function getRecommendedProducts()
    {
        if (!$this->isEnabled()) {
            return [];
        }

        $limit = $this->helper->getProductsCount();
        return $this->recommendationEngine->getRecommendedProducts($limit);
    }

    public function getProductImageUrl($product, $imageType = 'product_base_image')
    {
        return $this->imageHelper->init($product, $imageType)->getUrl();
    }

    public function getFormattedPrice($price)
    {
        return $this->priceHelper->currency($price, true, false);
    }

    public function getProductName($product)
    {
        return $this->outputHelper->productAttribute($product, $product->getName(), 'name');
    }
}