<?php
namespace Tychons\ProductRecommend\Model;

use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\CatalogInventory\Helper\Stock;
use Magento\Store\Model\StoreManagerInterface;

class RecommendationEngine
{
    protected $resource;
    protected $customerSession;
    protected $session;
    protected $productCollectionFactory;
    protected $stockHelper;
    protected $storeManager;

    public function __construct(
        ResourceConnection $resource,
        CustomerSession $customerSession,
        SessionManagerInterface $session,
        CollectionFactory $productCollectionFactory,
        Stock $stockHelper,
        StoreManagerInterface $storeManager
    ) {
        $this->resource = $resource;
        $this->customerSession = $customerSession;
        $this->session = $session;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->stockHelper = $stockHelper;
        $this->storeManager = $storeManager;
    }

    public function getRecommendedProducts($limit = 5)
    {
        $categoryIds = $this->getViewedCategoryIds();
        
        if (empty($categoryIds)) {
            // If no viewing history, return popular products
            return $this->getPopularProducts($limit);
        }

        return $this->getProductsByCategories($categoryIds, $limit);
    }

    protected function getViewedCategoryIds()
    {
        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('personalization_productrecommend_customer_views');
        
        $customerId = $this->customerSession->getCustomerId();
        $sessionId = $this->session->getSessionId();

        $select = $connection->select()
            ->from($table, ['category_ids'])
            ->where('viewed_at > DATE_SUB(NOW(), INTERVAL 30 DAY)') // Last 30 days
            ->order('viewed_at DESC')
            ->limit(20); // Check last 20 viewed products

        if ($customerId) {
            $select->where('customer_id = ?', $customerId);
        } else {
            $select->where('session_id = ?', $sessionId);
        }

        $results = $connection->fetchCol($select);
        
        $categoryIds = [];
        foreach ($results as $categories) {
            if ($categories) {
                $cats = explode(',', $categories);
                $categoryIds = array_merge($categoryIds, $cats);
            }
        }

        return array_unique(array_filter($categoryIds));
    }

    protected function getProductsByCategories($categoryIds, $limit)
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect(['name', 'price', 'image', 'small_image'])
            ->addAttributeToFilter('status', \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED)
            ->addAttributeToFilter('visibility', [
                'in' => [
                    \Magento\Catalog\Model\Product\Visibility::VISIBILITY_IN_CATALOG,
                    \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH
                ]
            ])
            ->addStoreFilter($this->storeManager->getStore()->getId());

        // Add category filter
        $collection->addCategoriesFilter(['in' => $categoryIds]);

        // Add stock filter - only in stock products
        $this->stockHelper->addInStockFilterToCollection($collection);

        // Exclude already viewed products
        $viewedProductIds = $this->getViewedProductIds();
        if (!empty($viewedProductIds)) {
            $collection->addAttributeToFilter('entity_id', ['nin' => $viewedProductIds]);
        }

        $collection->getSelect()->order('RAND()'); // Random order
        $collection->setPageSize($limit);

        return $collection;
    }

    protected function getViewedProductIds()
    {
        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('personalization_productrecommend_customer_views');
        
        $customerId = $this->customerSession->getCustomerId();
        $sessionId = $this->session->getSessionId();

        $select = $connection->select()
            ->from($table, ['product_id'])
            ->where('viewed_at > DATE_SUB(NOW(), INTERVAL 7 DAY)'); // Last 7 days

        if ($customerId) {
            $select->where('customer_id = ?', $customerId);
        } else {
            $select->where('session_id = ?', $sessionId);
        }

        return $connection->fetchCol($select);
    }

    protected function getPopularProducts($limit)
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect(['name', 'price', 'image', 'small_image'])
            ->addAttributeToFilter('status', \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED)
            ->addAttributeToFilter('visibility', [
                'in' => [
                    \Magento\Catalog\Model\Product\Visibility::VISIBILITY_IN_CATALOG,
                    \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH
                ]
            ])
            ->addStoreFilter($this->storeManager->getStore()->getId());

        // Add stock filter - only in stock products
        $this->stockHelper->addInStockFilterToCollection($collection);

        $collection->getSelect()->order('RAND()'); // Random order for popular products
        $collection->setPageSize($limit);

        return $collection;
    }
}