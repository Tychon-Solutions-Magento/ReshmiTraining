<?php
namespace Tychons\ProductRecommend\Model;

use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Catalog\Model\Product;

class ViewTracker
{
    protected $resource;
    protected $customerSession;
    protected $session;

    public function __construct(
        ResourceConnection $resource,
        CustomerSession $customerSession,
        SessionManagerInterface $session
    ) {
        $this->resource = $resource;
        $this->customerSession = $customerSession;
        $this->session = $session;
    }

    public function track(Product $product)
    {
        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('personalization_productrecommend_customer_views');

        $customerId = $this->customerSession->getCustomerId();
        $sessionId = $this->session->getSessionId();

        $connection->insert($table, [
            'customer_id' => $customerId,
            'session_id' => $sessionId,
            'product_id' => $product->getId(),
            'category_ids' => implode(',', $product->getCategoryIds()),
            'viewed_at' => date('Y-m-d H:i:s')
        ]);
    }
}
