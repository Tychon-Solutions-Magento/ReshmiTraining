<?php
namespace Tychons\ProductInquiry\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    public function isEnabled()
    {
        return true;  
    }
}